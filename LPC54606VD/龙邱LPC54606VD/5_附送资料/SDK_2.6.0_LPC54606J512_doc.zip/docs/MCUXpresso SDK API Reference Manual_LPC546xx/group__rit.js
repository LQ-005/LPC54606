var group__rit =
[
    [ "rit_config_t", "group__rit.html#structrit__config__t", [
      [ "enableRunInDebug", "group__rit.html#a3e106a6500a4a4c3569aae7dbf96000b", null ]
    ] ],
    [ "FSL_RIT_DRIVER_VERSION", "group__rit.html#ga5a69b572403c9a5773101236d8a54b8b", null ],
    [ "rit_status_flags_t", "group__rit.html#gab5626c9c36058435300734442d173fe5", [
      [ "kRIT_TimerFlag", "group__rit.html#ggab5626c9c36058435300734442d173fe5a1c5b6cb1d18ba19f244f690ea23a0fd4", null ]
    ] ],
    [ "RIT_Init", "group__rit.html#ga948471fc6c4c508f5575e972f3e6f769", null ],
    [ "RIT_Deinit", "group__rit.html#ga44040256e28fadf1c958114c02f490a1", null ],
    [ "RIT_GetDefaultConfig", "group__rit.html#ga767bfb2cb206d8f794e404cca7496aa3", null ],
    [ "RIT_GetStatusFlags", "group__rit.html#ga7e3bc882c4f20ca646133f7f9f0430b6", null ],
    [ "RIT_ClearStatusFlags", "group__rit.html#gadf96e78c01ae1500522e74a5ce57fd92", null ],
    [ "RIT_SetTimerCompare", "group__rit.html#ga444577332e6d95416675c2761b8c9465", null ],
    [ "RIT_SetMaskBit", "group__rit.html#ga4194bfcbfd81d33c1192317c00e61972", null ],
    [ "RIT_GetCompareTimerCount", "group__rit.html#ga5501839d934bcf3160527e2d0ad807ba", null ],
    [ "RIT_GetCounterTimerCount", "group__rit.html#ga9664fc91f3588ab18307ce52ace9cbe3", null ],
    [ "RIT_GetMaskTimerCount", "group__rit.html#ga2393f840ed6d0cad154926bf8061f399", null ],
    [ "RIT_StartTimer", "group__rit.html#ga27efb8c860834dc558fbef83727d406e", null ],
    [ "RIT_StopTimer", "group__rit.html#ga20b0e79037661c5fab78ab0a4c780dec", null ],
    [ "RIT_ClearCounter", "group__rit.html#ga9adf55a97d9332f2f00a24ced0f7f5c0", null ],
    [ "RIT_SetCountAutoClear", "group__rit.html#ga446e90e0768b43125c55f1a3a473fe6c", null ]
];