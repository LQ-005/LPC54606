var group__Timer =
[
    [ "timer_config_t", "group__Timer.html#structtimer__config__t", [
      [ "srcClock_Hz", "group__Timer.html#a89646b4757dc1a8a9ea60095d11f7f26", null ],
      [ "instance", "group__Timer.html#a0e82a4e0f1e710364a4c78277eb10e2a", null ]
    ] ],
    [ "TM_COMMON_TASK_ENABLE", "group__Timer.html#ga72f8843b02aa54036e14ec25bd440442", null ],
    [ "timer_status_t", "group__Timer.html#ga5642da239107a4b2f5ee610f9d5b98f5", [
      [ "kStatus_TimerSuccess", "group__Timer.html#gga5642da239107a4b2f5ee610f9d5b98f5a0c6eb102d94340d3e30612dd8dc8a83f", null ],
      [ "kStatus_TimerInvalidId", "group__Timer.html#gga5642da239107a4b2f5ee610f9d5b98f5aa57c77145092086b436d82818d5b3a6c", null ],
      [ "kStatus_TimerNotSupport", "group__Timer.html#gga5642da239107a4b2f5ee610f9d5b98f5a7c83ba44797b43e22345ee2a2eda4194", null ],
      [ "kStatus_TimerOutOfRange", "group__Timer.html#gga5642da239107a4b2f5ee610f9d5b98f5a8f998f90d18ce88604f59d64182e6c18", null ],
      [ "kStatus_TimerError", "group__Timer.html#gga5642da239107a4b2f5ee610f9d5b98f5a8731a5fb9c9c9819477b3f6ff3ebdbe6", null ]
    ] ],
    [ "timer_mode_t", "group__Timer.html#ga6d4cd64aed5c0009ac26803efc9c13b2", [
      [ "kTimerModeSingleShot", "group__Timer.html#gga6d4cd64aed5c0009ac26803efc9c13b2a2a160f58880f30e84e11fed61ce92e3d", null ],
      [ "kTimerModeIntervalTimer", "group__Timer.html#gga6d4cd64aed5c0009ac26803efc9c13b2a8059883f4b02b3bd9e8e8084a1def388", null ],
      [ "kTimerModeSetMinuteTimer", "group__Timer.html#gga6d4cd64aed5c0009ac26803efc9c13b2a61ed62fcfb8748dc4656762606e8b7b9", null ],
      [ "kTimerModeSetSecondTimer", "group__Timer.html#gga6d4cd64aed5c0009ac26803efc9c13b2a3211a53764351054b68a3f3e12663583", null ],
      [ "kTimerModeLowPowerTimer", "group__Timer.html#gga6d4cd64aed5c0009ac26803efc9c13b2a60e944f0474fdad7008c3f07f950a823", null ]
    ] ],
    [ "TM_Init", "group__Timer.html#ga0148c33d19e346e64c82090406ea23a2", null ],
    [ "TM_Deinit", "group__Timer.html#ga8e686bfb43bd3b61e49c7fd9b71071af", null ],
    [ "TM_ExitLowpower", "group__Timer.html#ga526895a57fe8b1a3fbc4c8f00d7bbab7", null ],
    [ "TM_EnterLowpower", "group__Timer.html#ga9b70d887645c0c0b0b777f1ea1bfc69a", null ],
    [ "TM_Open", "group__Timer.html#ga83cbe4de899abbcf13df01415d3f69ea", null ],
    [ "TM_Close", "group__Timer.html#ga6c8bba53f6c004a54db1765951c8f477", null ],
    [ "TM_InstallCallback", "group__Timer.html#gaadd4a05bc0e3a7142e6c094885c8d65f", null ],
    [ "TM_Start", "group__Timer.html#gad25dd8338546d24f09935217e196b0a2", null ],
    [ "TM_Stop", "group__Timer.html#ga706aca27c7deb38262e872855cb54f69", null ],
    [ "TM_IsTimerActive", "group__Timer.html#ga97a7edac7168e680c3360ac0c1fc1f70", null ],
    [ "TM_IsTimerReady", "group__Timer.html#gab558fb1d349c1908cff276062ecbdbce", null ],
    [ "TM_GetRemainingTime", "group__Timer.html#gaa2d0a054ca4545f0fc5c5f9693840609", null ],
    [ "TM_GetFirstExpireTime", "group__Timer.html#ga9bdf6fdecd9fbe46b7a3ce37a966a8d4", null ],
    [ "TM_GetFirstTimerWithParam", "group__Timer.html#ga3a92dc62171b1086958ed06f6a88b031", null ],
    [ "TM_AreAllTimersOff", "group__Timer.html#ga6c4ba7d6d092adcd5b2625a81206b791", null ],
    [ "TM_NotCountedTimeBeforeSleep", "group__Timer.html#gab319932675c3473d78a73b58044fe203", null ],
    [ "TM_SyncLpmTimers", "group__Timer.html#gacb82f7c1d665d4be22e7ce414fc301ae", null ],
    [ "TM_MakeTimerTaskReady", "group__Timer.html#ga5935a99ee1f2e0e329b51be5b0c8e03e", null ]
];