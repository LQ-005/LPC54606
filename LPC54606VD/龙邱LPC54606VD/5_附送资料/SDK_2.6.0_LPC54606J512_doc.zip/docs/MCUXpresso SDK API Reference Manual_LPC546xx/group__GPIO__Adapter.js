var group__GPIO__Adapter =
[
    [ "hal_gpio_pin_config_t", "group__GPIO__Adapter.html#structhal__gpio__pin__config__t", null ],
    [ "HAL_GPIO_HANDLE_SIZE", "group__GPIO__Adapter.html#gad1ff800159c6fbb84493f5cdc645432c", null ],
    [ "HAL_GPIO_HANDLE_ISR_PRIORITY", "group__GPIO__Adapter.html#gaa2b85526e31b5cae6585a8f46cda5d13", null ],
    [ "hal_gpio_handle_t", "group__GPIO__Adapter.html#ga65ce2559011621a603cdb375b1a2bc10", null ],
    [ "hal_gpio_callback_t", "group__GPIO__Adapter.html#gad4a2e0e1b0d854d5b1b00fe015a3bac4", null ],
    [ "hal_gpio_interrupt_trigger_t", "group__GPIO__Adapter.html#gaa1d33a51005d3e09aac53d1ff8371462", [
      [ "kHAL_GpioInterruptDisable", "group__GPIO__Adapter.html#ggaa1d33a51005d3e09aac53d1ff8371462a19e245a207055a462d7b684376319aa3", null ],
      [ "kHAL_GpioInterruptLogicZero", "group__GPIO__Adapter.html#ggaa1d33a51005d3e09aac53d1ff8371462ad611d9ca5c2f4572712b3ce1dcdbf98d", null ],
      [ "kHAL_GpioInterruptRisingEdge", "group__GPIO__Adapter.html#ggaa1d33a51005d3e09aac53d1ff8371462ab0ccf49e7904e6a083e28b89159da950", null ],
      [ "kHAL_GpioInterruptFallingEdge", "group__GPIO__Adapter.html#ggaa1d33a51005d3e09aac53d1ff8371462a47214e3c4dff497c461b6f812b03e4f3", null ],
      [ "kHAL_GpioInterruptEitherEdge", "group__GPIO__Adapter.html#ggaa1d33a51005d3e09aac53d1ff8371462a99e471268275bb559030828da421f730", null ],
      [ "kHAL_GpioInterruptLogicOne", "group__GPIO__Adapter.html#ggaa1d33a51005d3e09aac53d1ff8371462a62a017fe84cb1e3e6f6517c5a48c6c89", null ]
    ] ],
    [ "hal_gpio_status_t", "group__GPIO__Adapter.html#ga6da2d541a690db510ae5d61ed0c83b9f", [
      [ "kStatus_HAL_GpioSuccess", "group__GPIO__Adapter.html#gga6da2d541a690db510ae5d61ed0c83b9fa5903d91b0a36fae56343b70e28bfbc73", null ],
      [ "kStatus_HAL_GpioError", "group__GPIO__Adapter.html#gga6da2d541a690db510ae5d61ed0c83b9fa46ce17feb4331481dc52f3e27181062f", null ],
      [ "kStatus_HAL_GpioLackSource", "group__GPIO__Adapter.html#gga6da2d541a690db510ae5d61ed0c83b9fa87ffa7e2311ef2af0cf6dcc8d79d522b", null ],
      [ "kStatus_HAL_GpioPinConflict", "group__GPIO__Adapter.html#gga6da2d541a690db510ae5d61ed0c83b9fa024fa4dea911489ef91638f35bf23206", null ]
    ] ],
    [ "hal_gpio_direction_t", "group__GPIO__Adapter.html#ga542728e7f1595592548392d692286b2c", [
      [ "kHAL_GpioDirectionOut", "group__GPIO__Adapter.html#gga542728e7f1595592548392d692286b2ca5fbf1f1a1e8292157ec956ea1bef651b", null ],
      [ "kHAL_GpioDirectionIn", "group__GPIO__Adapter.html#gga542728e7f1595592548392d692286b2ca4ebe7e79058e290be73bc32620922517", null ]
    ] ],
    [ "HAL_GpioInit", "group__GPIO__Adapter.html#ga733be30defa2e46c4afbe8661882e8f2", null ],
    [ "HAL_GpioDeinit", "group__GPIO__Adapter.html#gafdea9fc54e9555f43912d26cdfe2a576", null ],
    [ "HAL_GpioGetInput", "group__GPIO__Adapter.html#gae3a318a3a47b498f57860fd6bf22b7a3", null ],
    [ "HAL_GpioSetOutput", "group__GPIO__Adapter.html#gad4b2680fa80554d9c0ba3634b938d679", null ],
    [ "HAL_GpioGetTriggerMode", "group__GPIO__Adapter.html#ga6c1c7a9439ca936e4e6f26a0c850ee6d", null ],
    [ "HAL_GpioSetTriggerMode", "group__GPIO__Adapter.html#ga9bd9724d8bbc2a7a7367e6ab23a230aa", null ],
    [ "HAL_GpioInstallCallback", "group__GPIO__Adapter.html#gaf8707d8512d654de7b5f1712bb12a8a1", null ],
    [ "HAL_GpioWakeUpSetting", "group__GPIO__Adapter.html#gaa13d0af2f7eb0c51c40adca193c38428", null ],
    [ "HAL_GpioEnterLowpower", "group__GPIO__Adapter.html#gab37ef1ed8f02410a225c602f1905094e", null ],
    [ "HAL_GpioExitLowpower", "group__GPIO__Adapter.html#gab81b254b46bf34caad7e770c76b8f3a4", null ]
];