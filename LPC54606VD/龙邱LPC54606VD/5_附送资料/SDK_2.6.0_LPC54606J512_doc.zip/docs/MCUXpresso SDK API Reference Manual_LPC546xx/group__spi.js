var group__spi =
[
    [ "SPI DMA Driver", "group__spi__dma__driver.html", "group__spi__dma__driver" ],
    [ "SPI Driver", "group__spi__driver.html", "group__spi__driver" ],
    [ "SPI FreeRTOS driver", "group__spi__freertos__driver.html", "group__spi__freertos__driver" ]
];