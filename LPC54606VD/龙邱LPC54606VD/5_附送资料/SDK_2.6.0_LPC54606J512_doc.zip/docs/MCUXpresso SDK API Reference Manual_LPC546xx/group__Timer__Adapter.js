var group__Timer__Adapter =
[
    [ "hal_timer_config_t", "group__Timer__Adapter.html#structhal__timer__config__t", [
      [ "timeout", "group__Timer__Adapter.html#a9f457b4afeece8b67f984b8e2d383660", null ],
      [ "srcClock_Hz", "group__Timer__Adapter.html#a22ae44ce3cd52839a078e4b95adacc63", null ],
      [ "instance", "group__Timer__Adapter.html#ab88e016dba3824003ee40f25ae64add3", null ]
    ] ],
    [ "hal_timer_callback_t", "group__Timer__Adapter.html#ga3a11455ac6393e9d8ea9ed654dd0756b", null ],
    [ "hal_timer_handle_t", "group__Timer__Adapter.html#ga35758cf1fce36cd940d538daf3165399", null ],
    [ "hal_timer_status_t", "group__Timer__Adapter.html#ga729d66a277394b0d9d455aeb14fa56bd", [
      [ "kStatus_HAL_TimerSuccess", "group__Timer__Adapter.html#gga729d66a277394b0d9d455aeb14fa56bdae256fcce2a4cd225168efd0a662ddcfc", null ],
      [ "kStatus_HAL_TimerNotSupport", "group__Timer__Adapter.html#gga729d66a277394b0d9d455aeb14fa56bdab4b44989b75505fbed81d8eee3976255", null ],
      [ "kStatus_HAL_TimerIsUsed", "group__Timer__Adapter.html#gga729d66a277394b0d9d455aeb14fa56bda6d6956bc9554d534043da0855d2cec00", null ],
      [ "kStatus_HAL_TimerInvalid", "group__Timer__Adapter.html#gga729d66a277394b0d9d455aeb14fa56bda662e7bd37fc3286e8135c7efa14e2316", null ],
      [ "kStatus_HAL_TimerOutOfRanger", "group__Timer__Adapter.html#gga729d66a277394b0d9d455aeb14fa56bdaf3fc04b2b1ba644250ff41affafa0ee9", null ]
    ] ],
    [ "HAL_TimerInit", "group__Timer__Adapter.html#ga6825121005619166bb45a015865e0bb4", null ],
    [ "HAL_TimerDeinit", "group__Timer__Adapter.html#gaa16fb6566957426fca21d20562ee67cf", null ],
    [ "HAL_TimerEnable", "group__Timer__Adapter.html#ga738eaee86db97258d314fb3bfc8d4c77", null ],
    [ "HAL_TimerDisable", "group__Timer__Adapter.html#gac10258d291cf706f6ff6fa8e5a563bd3", null ],
    [ "HAL_TimerInstallCallback", "group__Timer__Adapter.html#ga78e4214e8f6ae346313803f303738ad5", null ],
    [ "HAL_TimerGetCurrentTimerCount", "group__Timer__Adapter.html#gaabce0f8b54bd41b8a34bb293e8041b9e", null ],
    [ "HAL_TimerUpdateTimeout", "group__Timer__Adapter.html#gaf2e8a770363b0a08dd8719335bb55393", null ],
    [ "HAL_TimerGetMaxTimeout", "group__Timer__Adapter.html#ga5f95db67f72d937e9775f9da5ed34a1c", null ],
    [ "HAL_TimerExitLowpower", "group__Timer__Adapter.html#ga2193e8c1c6115f7735e11a6492835a82", null ],
    [ "HAL_TimerEnterLowpower", "group__Timer__Adapter.html#ga66142ca9f7726c8beedabb6c5c03515b", null ]
];