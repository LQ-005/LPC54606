var group__Panic =
[
    [ "panic_data_t", "group__Panic.html#structpanic__data__t", null ],
    [ "PANIC_ENABLE_LOG", "group__Panic.html#gad6e741cc59f445aa984c04116a1ba34a", null ],
    [ "panic_id_t", "group__Panic.html#gaa99f09dd0147e90ef2e7c500b25b2f7e", null ],
    [ "panic", "group__Panic.html#ga1f58b037fefb8cfbe6faec460b768c3d", null ]
];