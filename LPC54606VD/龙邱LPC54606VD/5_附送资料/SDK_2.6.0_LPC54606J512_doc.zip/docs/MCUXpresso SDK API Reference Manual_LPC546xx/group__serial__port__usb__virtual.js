var group__serial__port__usb__virtual =
[
    [ "serial_port_usb_cdc_virtual_config_t", "group__serial__port__usb__virtual.html#structserial__port__usb__cdc__virtual__config__t", [
      [ "controllerIndex", "group__serial__port__usb__virtual.html#ga7436151182883e8bd598c81879c107b3", null ]
    ] ],
    [ "SERIAL_PORT_USB_VIRTUAL_HANDLE_SIZE", "group__serial__port__usb__virtual.html#gaa8e5145650a08bf62eb00c939376a38c", null ],
    [ "serial_port_usb_cdc_virtual_controller_index_t", "group__serial__port__usb__virtual.html#ga915bdb13b88d0a743fb297133a088ac9", [
      [ "kSerialManager_UsbVirtualControllerKhci0", "group__serial__port__usb__virtual.html#gga915bdb13b88d0a743fb297133a088ac9a684bd5113d0a9e9e3b44fb346f167c88", null ],
      [ "kSerialManager_UsbVirtualControllerKhci1", "group__serial__port__usb__virtual.html#gga915bdb13b88d0a743fb297133a088ac9a249c564ae2e8bbddd33a8f1b7e3bca2a", null ],
      [ "kSerialManager_UsbVirtualControllerEhci0", "group__serial__port__usb__virtual.html#gga915bdb13b88d0a743fb297133a088ac9a7cac9c3492620051b00f2bf126777b00", null ],
      [ "kSerialManager_UsbVirtualControllerEhci1", "group__serial__port__usb__virtual.html#gga915bdb13b88d0a743fb297133a088ac9aeae3ed67659bcedbdca596c6beba565d", null ],
      [ "kSerialManager_UsbVirtualControllerLpcIp3511Fs0", "group__serial__port__usb__virtual.html#gga915bdb13b88d0a743fb297133a088ac9a3393b78c3383b85d76a9c98ddccf8cd6", null ],
      [ "kSerialManager_UsbVirtualControllerLpcIp3511Fs1", "group__serial__port__usb__virtual.html#gga915bdb13b88d0a743fb297133a088ac9af16d92a2527254118a3b6ec00a8223db", null ],
      [ "kSerialManager_UsbVirtualControllerLpcIp3511Hs0", "group__serial__port__usb__virtual.html#gga915bdb13b88d0a743fb297133a088ac9ac46b5bfecc233f3efbb3a5706288e118", null ],
      [ "kSerialManager_UsbVirtualControllerLpcIp3511Hs1", "group__serial__port__usb__virtual.html#gga915bdb13b88d0a743fb297133a088ac9a17428b40411cca0917702a9e496ec4ed", null ],
      [ "kSerialManager_UsbVirtualControllerOhci0", "group__serial__port__usb__virtual.html#gga915bdb13b88d0a743fb297133a088ac9aca475227c0742edbf794e7a15d44abad", null ],
      [ "kSerialManager_UsbVirtualControllerOhci1", "group__serial__port__usb__virtual.html#gga915bdb13b88d0a743fb297133a088ac9a68a0656bb91c2eab1928246851d38902", null ],
      [ "kSerialManager_UsbVirtualControllerIp3516Hs0", "group__serial__port__usb__virtual.html#gga915bdb13b88d0a743fb297133a088ac9ab4093a5995c802f571f14b0f10577886", null ],
      [ "kSerialManager_UsbVirtualControllerIp3516Hs1", "group__serial__port__usb__virtual.html#gga915bdb13b88d0a743fb297133a088ac9a9759faa2f2269cd227f5fec3c58d118d", null ]
    ] ],
    [ "kSerialManager_UsbVirtualControllerKhci0", "group__serial__port__usb__virtual.html#gga915bdb13b88d0a743fb297133a088ac9a684bd5113d0a9e9e3b44fb346f167c88", null ],
    [ "kSerialManager_UsbVirtualControllerKhci1", "group__serial__port__usb__virtual.html#gga915bdb13b88d0a743fb297133a088ac9a249c564ae2e8bbddd33a8f1b7e3bca2a", null ],
    [ "kSerialManager_UsbVirtualControllerEhci0", "group__serial__port__usb__virtual.html#gga915bdb13b88d0a743fb297133a088ac9a7cac9c3492620051b00f2bf126777b00", null ],
    [ "kSerialManager_UsbVirtualControllerEhci1", "group__serial__port__usb__virtual.html#gga915bdb13b88d0a743fb297133a088ac9aeae3ed67659bcedbdca596c6beba565d", null ],
    [ "kSerialManager_UsbVirtualControllerLpcIp3511Fs0", "group__serial__port__usb__virtual.html#gga915bdb13b88d0a743fb297133a088ac9a3393b78c3383b85d76a9c98ddccf8cd6", null ],
    [ "kSerialManager_UsbVirtualControllerLpcIp3511Fs1", "group__serial__port__usb__virtual.html#gga915bdb13b88d0a743fb297133a088ac9af16d92a2527254118a3b6ec00a8223db", null ],
    [ "kSerialManager_UsbVirtualControllerLpcIp3511Hs0", "group__serial__port__usb__virtual.html#gga915bdb13b88d0a743fb297133a088ac9ac46b5bfecc233f3efbb3a5706288e118", null ],
    [ "kSerialManager_UsbVirtualControllerLpcIp3511Hs1", "group__serial__port__usb__virtual.html#gga915bdb13b88d0a743fb297133a088ac9a17428b40411cca0917702a9e496ec4ed", null ],
    [ "kSerialManager_UsbVirtualControllerOhci0", "group__serial__port__usb__virtual.html#gga915bdb13b88d0a743fb297133a088ac9aca475227c0742edbf794e7a15d44abad", null ],
    [ "kSerialManager_UsbVirtualControllerOhci1", "group__serial__port__usb__virtual.html#gga915bdb13b88d0a743fb297133a088ac9a68a0656bb91c2eab1928246851d38902", null ],
    [ "kSerialManager_UsbVirtualControllerIp3516Hs0", "group__serial__port__usb__virtual.html#gga915bdb13b88d0a743fb297133a088ac9ab4093a5995c802f571f14b0f10577886", null ],
    [ "kSerialManager_UsbVirtualControllerIp3516Hs1", "group__serial__port__usb__virtual.html#gga915bdb13b88d0a743fb297133a088ac9a9759faa2f2269cd227f5fec3c58d118d", null ],
    [ "controllerIndex", "group__serial__port__usb__virtual.html#ga7436151182883e8bd598c81879c107b3", null ]
];