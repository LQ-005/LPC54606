var group__i2s =
[
    [ "I2S DMA Driver", "group__i2s__dma__driver.html", "group__i2s__dma__driver" ],
    [ "I2S Driver", "group__i2s__driver.html", "group__i2s__driver" ]
];