var group__LED =
[
    [ "led_pin_config_t", "group__LED.html#structled__pin__config__t", [
      [ "dimmingEnable", "group__LED.html#a127e3e6e8b49d37fcaff23d6210b3587", null ],
      [ "port", "group__LED.html#aaf435a73d894ec523fe3cfa24cd86f79", null ],
      [ "pin", "group__LED.html#a5f3a129aad7ab5e40c6afcae7aec871e", null ],
      [ "pinStateDefault", "group__LED.html#ad7d6795b4b5ee6aba2591fdd824d11e3", null ],
      [ "sourceClock", "group__LED.html#a00fd3f10595648def523daf2f280ef98", null ],
      [ "instance", "group__LED.html#a124f9dd43951c8a640db093aa041fc56", null ],
      [ "channel", "group__LED.html#a1d137968980dcec02ffd55113c88388e", null ]
    ] ],
    [ "led_rgb_config_t", "group__LED.html#structled__rgb__config__t", [
      [ "redPin", "group__LED.html#a5a298577d5ae27da17757fa3ca3436db", null ],
      [ "greenPin", "group__LED.html#a835152efe09363fdb1c7c1a4c8a525a4", null ],
      [ "bluePin", "group__LED.html#a18957fbf545c9c2ed681c666a89c3b4f", null ]
    ] ],
    [ "led_monochrome_config_t", "group__LED.html#structled__monochrome__config__t", [
      [ "monochromePin", "group__LED.html#aa2662364b7173767a9bf0472c5046653", null ]
    ] ],
    [ "led_config_t", "group__LED.html#structled__config__t", [
      [ "ledRgb", "group__LED.html#a2243bd49cf99dbf428456b2a6261e063", null ],
      [ "ledMonochrome", "group__LED.html#a485fcfd2ab80bd2d5d8b5b45c56dbcf2", null ]
    ] ],
    [ "led_flash_config_t", "group__LED.html#structled__flash__config__t", [
      [ "times", "group__LED.html#ad73a8ba299009c0bb2e681249f6dc59b", null ],
      [ "period", "group__LED.html#a3ae9b7974cb459f7f765941c6703e82b", null ],
      [ "flashType", "group__LED.html#a37858ac02b218f1c9dc4ea4e36375f0e", null ],
      [ "duty", "group__LED.html#a387db2bc1a4153753e51fdb32b5ab4a2", null ]
    ] ],
    [ "LED_DIMMING_ENABLEMENT", "group__LED.html#gab1c951f31df0dec0a76866f76e5fdacc", null ],
    [ "LED_HANDLE_SIZE", "group__LED.html#ga163c4226a9d58115ed32485eb7056da7", null ],
    [ "LED_TIMER_INTERVAL", "group__LED.html#gaa189c6766bd5be625917152cbbff1c95", null ],
    [ "LED_DIMMING_UPDATE_INTERVAL", "group__LED.html#ga28ef147d17735d1751ac771d53f20d36", null ],
    [ "LED_FLASH_CYCLE_FOREVER", "group__LED.html#ga0fcfb713f2c6b0af490d6b65d98416cb", null ],
    [ "LED_BLIP_INTERVAL", "group__LED.html#ga63fae0c4958dbf9353854dc1731c7e73", null ],
    [ "LED_MAKE_COLOR", "group__LED.html#ga59cb1a3d1b67b5efdf1832ee436445a7", null ],
    [ "led_handle_t", "group__LED.html#ga2e6f49cb4cfe9771f15be4734ebb21c2", null ],
    [ "led_color_t", "group__LED.html#ga49b09097ec358cb93e9b950a10debc05", null ],
    [ "led_status_t", "group__LED.html#gacefcb61df68bbf1e3b464156b1b8c333", [
      [ "kStatus_LED_Success", "group__LED.html#ggacefcb61df68bbf1e3b464156b1b8c333a8914efe44b8e4c0fc872a15524300e7a", null ],
      [ "kStatus_LED_Error", "group__LED.html#ggacefcb61df68bbf1e3b464156b1b8c333a739191d62d706a9399ecfb03c27501a7", null ],
      [ "kStatus_LED_InvalidParameter", "group__LED.html#ggacefcb61df68bbf1e3b464156b1b8c333ad4fb887fd148788c63a3823c3321086f", null ]
    ] ],
    [ "led_flash_type_t", "group__LED.html#gac144197aba6ea50ae0454ab2f1dec6c5", [
      [ "kLED_FlashOneColor", "group__LED.html#ggac144197aba6ea50ae0454ab2f1dec6c5a9ff53165a416cc96df5c736976950e0a", null ],
      [ "kLED_FlashColorWheel", "group__LED.html#ggac144197aba6ea50ae0454ab2f1dec6c5a3a974cfaa375c09f767004fa9dbd1e27", null ]
    ] ],
    [ "_led_color", "group__LED.html#gabd1b73f6693cfce35d0646bdc4968605", [
      [ "kLED_Black", "group__LED.html#ggabd1b73f6693cfce35d0646bdc4968605a2894a72f48bb95157b59bdfe1d4d5721", null ],
      [ "kLED_Red", "group__LED.html#ggabd1b73f6693cfce35d0646bdc4968605a923a3b2518bb69d5025b9e9621cc0ae8", null ],
      [ "kLED_Green", "group__LED.html#ggabd1b73f6693cfce35d0646bdc4968605a03e3f035a538d513be60d9ba32a5539a", null ],
      [ "kLED_Yellow", "group__LED.html#ggabd1b73f6693cfce35d0646bdc4968605a307e5504d9e9a1c510ebd0de840a9e1f", null ],
      [ "kLED_Blue", "group__LED.html#ggabd1b73f6693cfce35d0646bdc4968605a59ee5d6c7a715234164c9a030c4d3f9b", null ],
      [ "kLED_Pink", "group__LED.html#ggabd1b73f6693cfce35d0646bdc4968605a8f4e99975514a3639a398304078d08e1", null ],
      [ "kLED_Aquamarine", "group__LED.html#ggabd1b73f6693cfce35d0646bdc4968605a1cacba6b1843e879dd4a5a85fca55435", null ],
      [ "kLED_White", "group__LED.html#ggabd1b73f6693cfce35d0646bdc4968605ad6d014a95c481f9044290264c559f78d", null ]
    ] ],
    [ "led_type_t", "group__LED.html#ga350653f0391f08df8b4bbc87ab0e3a37", [
      [ "kLED_TypeRgb", "group__LED.html#gga350653f0391f08df8b4bbc87ab0e3a37aebe359c12bfcbab9849f3a3d3de8c7cc", null ],
      [ "kLED_TypeMonochrome", "group__LED.html#gga350653f0391f08df8b4bbc87ab0e3a37ad89ac5514e2522e2625af7fed9c80d43", null ]
    ] ],
    [ "LED_Init", "group__LED.html#gab4b3f589afbea3b697bc9e3359ca69c2", null ],
    [ "LED_Deinit", "group__LED.html#ga2937c4494d92a597fcc26518159ed53c", null ],
    [ "LED_SetColor", "group__LED.html#gaf75e0b24785ccbff5d3b18af0b5bd20d", null ],
    [ "LED_TurnOnOff", "group__LED.html#gaeab8885cb349165278342341925407fb", null ],
    [ "LED_Blip", "group__LED.html#gaa498b1f9d3f12329706437e5d97762df", null ],
    [ "LED_Flash", "group__LED.html#ga603876bbd160829da7e70c4d85f62616", null ],
    [ "LED_Dimming", "group__LED.html#ga872dcf0908843f30c377a0bc4937adaa", null ],
    [ "LED_EnterLowpower", "group__LED.html#ga95b0a22da0369cdd31e66ff88493adad", null ],
    [ "LED_ExitLowpower", "group__LED.html#ga26719ed8ec8ac56822f858291e013c94", null ]
];