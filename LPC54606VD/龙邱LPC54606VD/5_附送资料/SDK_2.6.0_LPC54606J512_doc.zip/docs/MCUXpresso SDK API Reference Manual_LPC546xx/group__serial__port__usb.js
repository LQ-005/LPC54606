var group__serial__port__usb =
[
    [ "USB Device Configuration", "group__usb__device__configuration.html", "group__usb__device__configuration" ],
    [ "serial_port_usb_cdc_config_t", "group__serial__port__usb.html#structserial__port__usb__cdc__config__t", [
      [ "controllerIndex", "group__serial__port__usb.html#a164ef9f84df063b85674cc8aa6edd872", null ]
    ] ],
    [ "SERIAL_PORT_USB_CDC_HANDLE_SIZE", "group__serial__port__usb.html#ga360a6c81305a4e09848df9aece70ad40", null ],
    [ "USB_DEVICE_INTERRUPT_PRIORITY", "group__serial__port__usb.html#ga9fb260c0db8e2e75fa339416c82084b9", null ],
    [ "serial_port_usb_cdc_controller_index_t", "group__serial__port__usb.html#ga0d579054cbf9827f77f7018cd6f84c29", [
      [ "kSerialManager_UsbControllerKhci0", "group__serial__port__usb.html#gga0d579054cbf9827f77f7018cd6f84c29aba414efbedc13dd6605fdc76daee832f", null ],
      [ "kSerialManager_UsbControllerKhci1", "group__serial__port__usb.html#gga0d579054cbf9827f77f7018cd6f84c29a2992ed3c36bb733a2f3760b8a5927fdd", null ],
      [ "kSerialManager_UsbControllerEhci0", "group__serial__port__usb.html#gga0d579054cbf9827f77f7018cd6f84c29aa9a69ebd4f3d306f583cb23ff5bc8aad", null ],
      [ "kSerialManager_UsbControllerEhci1", "group__serial__port__usb.html#gga0d579054cbf9827f77f7018cd6f84c29a48e611ec0653efbf4a8b01168b8668b3", null ],
      [ "kSerialManager_UsbControllerLpcIp3511Fs0", "group__serial__port__usb.html#gga0d579054cbf9827f77f7018cd6f84c29afd13021033517524c07c581fa500a83d", null ],
      [ "kSerialManager_UsbControllerLpcIp3511Fs1", "group__serial__port__usb.html#gga0d579054cbf9827f77f7018cd6f84c29a4fc76a970dded05f11d3adc8c99880c3", null ],
      [ "kSerialManager_UsbControllerLpcIp3511Hs0", "group__serial__port__usb.html#gga0d579054cbf9827f77f7018cd6f84c29a78c55818f572f8120a85f13337ec9274", null ],
      [ "kSerialManager_UsbControllerLpcIp3511Hs1", "group__serial__port__usb.html#gga0d579054cbf9827f77f7018cd6f84c29a3e09ecce4e5aee8338fa0d1574139d47", null ],
      [ "kSerialManager_UsbControllerOhci0", "group__serial__port__usb.html#gga0d579054cbf9827f77f7018cd6f84c29acb150e43e1572c4f7abb9b374783ba30", null ],
      [ "kSerialManager_UsbControllerOhci1", "group__serial__port__usb.html#gga0d579054cbf9827f77f7018cd6f84c29a2a98602358806c8f01cdbe42cc4c763c", null ],
      [ "kSerialManager_UsbControllerIp3516Hs0", "group__serial__port__usb.html#gga0d579054cbf9827f77f7018cd6f84c29a51d953a091b2650c6b8283e2ce5639ae", null ],
      [ "kSerialManager_UsbControllerIp3516Hs1", "group__serial__port__usb.html#gga0d579054cbf9827f77f7018cd6f84c29a863a8a6669f791ce5b5207b3d85c6664", null ]
    ] ]
];