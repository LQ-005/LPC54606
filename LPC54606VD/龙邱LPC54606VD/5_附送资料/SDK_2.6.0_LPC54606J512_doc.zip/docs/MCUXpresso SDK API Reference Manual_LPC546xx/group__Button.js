var group__Button =
[
    [ "button_callback_message_t", "group__Button.html#structbutton__callback__message__t", null ],
    [ "button_gpio_config_t", "group__Button.html#structbutton__gpio__config__t", [
      [ "port", "group__Button.html#ae53b4bc1f2866641958f5342c2d45976", null ],
      [ "pin", "group__Button.html#abeb47ff98ada6c86dde936a089c25240", null ],
      [ "pinStateDefault", "group__Button.html#a7e91aa3f3ee2a3fa2f3a8100365fabf3", null ]
    ] ],
    [ "button_config_t", "group__Button.html#structbutton__config__t", null ],
    [ "BUTTON_HANDLE_SIZE", "group__Button.html#gafef8e8e41587b7d9add929f4aee41f9c", null ],
    [ "BUTTON_TIMER_INTERVAL", "group__Button.html#ga56f117a44ed962789c1f4916d61ef092", null ],
    [ "BUTTON_SHORT_PRESS_THRESHOLD", "group__Button.html#ga7f8d7d8e8d31a99c47dd4e77daa6487f", null ],
    [ "BUTTON_LONG_PRESS_THRESHOLD", "group__Button.html#ga27c44cf8a736b2f4804884a612aec039", null ],
    [ "BUTTON_DOUBLE_CLICK_THRESHOLD", "group__Button.html#gab9c680f3e07eed6a724fc5fce44a9201", null ],
    [ "BUTTON_USE_COMMON_TASK", "group__Button.html#ga73bfe006f7ca2b88fe910174f1b0cfb2", null ],
    [ "BUTTON_TASK_PRIORITY", "group__Button.html#ga94dea431a1c059625b45f816ab129043", null ],
    [ "BUTTON_TASK_STACK_SIZE", "group__Button.html#gadbb9d0dfbf98763aa25c6a52814f0bf8", null ],
    [ "BUTTON_EVENT_BUTTON", "group__Button.html#gaf9f746f940d6fcf6cac0f6feaefb2108", null ],
    [ "button_handle_t", "group__Button.html#gacef6d632127df591a861222e28033be2", null ],
    [ "button_callback_t", "group__Button.html#ga2152e851fbba610c96061d35a0fc2149", null ],
    [ "button_status_t", "group__Button.html#gaad5e3af796911b3ef3ab549a45a24158", [
      [ "kStatus_BUTTON_Success", "group__Button.html#ggaad5e3af796911b3ef3ab549a45a24158a9df0d56e70b21e51a159a18930574ad6", null ],
      [ "kStatus_BUTTON_Error", "group__Button.html#ggaad5e3af796911b3ef3ab549a45a24158a4ba4ac2b75bfb65a975873bf294af420", null ],
      [ "kStatus_BUTTON_LackSource", "group__Button.html#ggaad5e3af796911b3ef3ab549a45a24158a30734bda949362586c403d2b02c1bf37", null ]
    ] ],
    [ "button_event_t", "group__Button.html#gaba6fb58d4ff9355f14b08a276b38058a", [
      [ "kBUTTON_EventOneClick", "group__Button.html#ggaba6fb58d4ff9355f14b08a276b38058aacda8422ae32e958eed0173804118a4b0", null ],
      [ "kBUTTON_EventDoubleClick", "group__Button.html#ggaba6fb58d4ff9355f14b08a276b38058aa6f550e9d94024674d594b37c6c17306b", null ],
      [ "kBUTTON_EventShortPress", "group__Button.html#ggaba6fb58d4ff9355f14b08a276b38058aa7587107b399e8c89f4bae0a141f83a9e", null ],
      [ "kBUTTON_EventLongPress", "group__Button.html#ggaba6fb58d4ff9355f14b08a276b38058aa45191a6e7a3c414a1d17b2b7bce403ce", null ],
      [ "kBUTTON_EventError", "group__Button.html#ggaba6fb58d4ff9355f14b08a276b38058aabfda2cf195b36408bf9266faa6f10775", null ]
    ] ],
    [ "BUTTON_Init", "group__Button.html#ga21bc086974d62b9d1ab06ade228b643e", null ],
    [ "BUTTON_InstallCallback", "group__Button.html#ga877fdaf67de1960b444d3edc95e0b0c4", null ],
    [ "BUTTON_Deinit", "group__Button.html#ga6ea4552de91b238d080c840e16f95504", null ],
    [ "BUTTON_WakeUpSetting", "group__Button.html#ga33f30b24edd2ed005ec17ea8af58636b", null ],
    [ "BUTTON_EnterLowpower", "group__Button.html#gac3c18e01c72182d8f399f94a2252dbae", null ],
    [ "BUTTON_ExitLowpower", "group__Button.html#gaa60fa09dbadfeb4816f979d6c9147b19", null ]
];