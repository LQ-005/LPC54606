var group__spi__freertos__driver =
[
    [ "spi_rtos_handle_t", "group__spi__freertos__driver.html#structspi__rtos__handle__t", [
      [ "base", "group__spi__freertos__driver.html#ad3f15e078040cf1bd904907745e27eb6", null ],
      [ "drv_handle", "group__spi__freertos__driver.html#ac3e2ad7cc73261936c0a737dc1be7393", null ],
      [ "mutex", "group__spi__freertos__driver.html#ad99230209eba3551c5ee0d0375b5e0c8", null ],
      [ "event", "group__spi__freertos__driver.html#ae09ff8fe9c2465890736b81371d186f8", null ]
    ] ],
    [ "FSL_SPI_FREERTOS_DRIVER_VERSION", "group__spi__freertos__driver.html#ga8703fba044d4b415536396f411a9933c", null ],
    [ "SPI_RTOS_Init", "group__spi__freertos__driver.html#gaa13fd290f152940848580b1222ab10f2", null ],
    [ "SPI_RTOS_Deinit", "group__spi__freertos__driver.html#ga7df6273b2a475fa37d1b70ad7ba69ddc", null ],
    [ "SPI_RTOS_Transfer", "group__spi__freertos__driver.html#gafbcc5ff867d6e4ab0a8139ba21745956", null ]
];