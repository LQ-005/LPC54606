var group__syscon =
[
    [ "FSL_SYSON_DRIVER_VERSION", "group__syscon.html#ga3d7a27cd4564bc389103aacd4a0a41e4", null ],
    [ "SYSCON_AttachSignal", "group__syscon.html#gaa42f53e7578284bdc9816da8800e735b", null ]
];