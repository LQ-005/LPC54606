var group__serial__port__swo =
[
    [ "serial_port_swo_config_t", "group__serial__port__swo.html#structserial__port__swo__config__t", [
      [ "clockRate", "group__serial__port__swo.html#a515e2f5ca8778fd65e10a0ac7f77d309", null ],
      [ "baudRate", "group__serial__port__swo.html#af06ab1ceb2156bba95ee5b125ef77e40", null ],
      [ "port", "group__serial__port__swo.html#aeab85500212c4b7945515d3acdf24aee", null ],
      [ "protocol", "group__serial__port__swo.html#a1fee1b1db63edc021f9b1d2e5808ecc0", null ]
    ] ],
    [ "SERIAL_PORT_SWO_HANDLE_SIZE", "group__serial__port__swo.html#ga65f815f28e5af3d42712ebefdd8662dc", null ],
    [ "serial_port_swo_protocol_t", "group__serial__port__swo.html#gab72244db50e88efd6d079d157558932d", [
      [ "kSerialManager_SwoProtocolManchester", "group__serial__port__swo.html#ggab72244db50e88efd6d079d157558932da57feeffbb98d786af19111f49bd6d733", null ],
      [ "kSerialManager_SwoProtocolNrz", "group__serial__port__swo.html#ggab72244db50e88efd6d079d157558932da1178f82728f1b7f27f28af46f8550d95", null ]
    ] ]
];