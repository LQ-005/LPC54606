var group__i2c =
[
    [ "I2C DMA Driver", "group__i2c__dma__driver.html", "group__i2c__dma__driver" ],
    [ "I2C Driver", "group__i2c__driver.html", "group__i2c__driver" ],
    [ "I2C FreeRTOS Driver", "group__i2c__freertos__driver.html", "group__i2c__freertos__driver" ],
    [ "I2C Master Driver", "group__i2c__master__driver.html", "group__i2c__master__driver" ],
    [ "I2C Slave Driver", "group__i2c__slave__driver.html", "group__i2c__slave__driver" ]
];