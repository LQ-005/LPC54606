var group__utick =
[
    [ "FSL_UTICK_DRIVER_VERSION", "group__utick.html#gaba15862a7512fc2a9c3bcccdb8b76bbf", null ],
    [ "utick_callback_t", "group__utick.html#ga4f7c7bdd94699bdc40c684a07f347c3f", null ],
    [ "utick_mode_t", "group__utick.html#ga18f6018b1dd6708a8ad6c90d4a6b2b51", [
      [ "kUTICK_Onetime", "group__utick.html#gga18f6018b1dd6708a8ad6c90d4a6b2b51aaeeddd009e9c2424172ad197ead2d97b", null ],
      [ "kUTICK_Repeat", "group__utick.html#gga18f6018b1dd6708a8ad6c90d4a6b2b51a865f02b62034aa073e56629375dee16e", null ]
    ] ],
    [ "UTICK_Init", "group__utick.html#ga612c590e311ff59c5036d9cf9b3d5141", null ],
    [ "UTICK_Deinit", "group__utick.html#ga926b042935b415c79beaa6d2552309e0", null ],
    [ "UTICK_GetStatusFlags", "group__utick.html#ga1073003f8cf4c006ee7b6258556b4df9", null ],
    [ "UTICK_ClearStatusFlags", "group__utick.html#ga42e9e599ac4c314382bc0e99f4ca4d52", null ],
    [ "UTICK_SetTick", "group__utick.html#ga5b314cad747ef275f03fb8cd11b524ee", null ],
    [ "UTICK_HandleIRQ", "group__utick.html#gaf1399bca52f347f0db63b88cda0973b8", null ]
];