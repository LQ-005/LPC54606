var searchData=
[
  ['sctimer_3a_20sctimer_2fpwm_20_28sct_29',['SCTimer: SCTimer/PWM (SCT)',['../group__sctimer.html',1,'']]],
  ['sdif_3a_20sd_2fmmc_2fsdio_20card_20interface',['SDIF: SD/MMC/SDIO card interface',['../group__sdif.html',1,'']]],
  ['semihosting',['Semihosting',['../group__Semihosting.html',1,'']]],
  ['serial_20port_20swo',['Serial Port SWO',['../group__serial__port__swo.html',1,'']]],
  ['serial_20port_20uart',['Serial Port Uart',['../group__serial__port__uart.html',1,'']]],
  ['serial_20port_20usb',['Serial Port USB',['../group__serial__port__usb.html',1,'']]],
  ['serial_20port_20virtual_20usb',['Serial Port Virtual USB',['../group__serial__port__usb__virtual.html',1,'']]],
  ['serial_20manager',['Serial Manager',['../group__serialmanager.html',1,'']]],
  ['spi_3a_20serial_20peripheral_20interface_20driver',['SPI: Serial Peripheral Interface Driver',['../group__spi.html',1,'']]],
  ['spi_20dma_20driver',['SPI DMA Driver',['../group__spi__dma__driver.html',1,'']]],
  ['spi_20driver',['SPI Driver',['../group__spi__driver.html',1,'']]],
  ['spi_20freertos_20driver',['SPI FreeRTOS driver',['../group__spi__freertos__driver.html',1,'']]],
  ['spifi_3a_20spifi_20flash_20interface_20driver',['SPIFI: SPIFI flash interface driver',['../group__spifi.html',1,'']]],
  ['spifi_20dma_20driver',['SPIFI DMA Driver',['../group__spifi__dma__driver.html',1,'']]],
  ['spifi_20driver',['SPIFI Driver',['../group__spifi__driver.html',1,'']]],
  ['swo',['SWO',['../group__SWO.html',1,'']]],
  ['syscon_3a_20system_20configuration',['SYSCON: System Configuration',['../group__syscon.html',1,'']]]
];
