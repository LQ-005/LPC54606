var searchData=
[
  ['next',['next',['../group__GenericList.html#a460f03213c38cd22939b93c36c3d5cd0',1,'list_element_t']]],
  ['nextdesc',['nextDesc',['../group__dma.html#a7bdfedca753e094b2c288f1cbb956889',1,'dma_channel_config_t::nextDesc()'],['../group__dma.html#a24f716a2b7775c1cb9a59b7c2374508b',1,'dma_transfer_config_t::nextDesc()']]],
  ['nmframe',['nmFrame',['../group__mcan.html#a9909dd860a3d76de6aa48ff3def1e71e',1,'mcan_frame_filter_config_t']]],
  ['number',['number',['../group__os__abstraction__bm.html#ad9821e6a3f798ee9f4e3f952c2a214ac',1,'msg_queue_t']]]
];
