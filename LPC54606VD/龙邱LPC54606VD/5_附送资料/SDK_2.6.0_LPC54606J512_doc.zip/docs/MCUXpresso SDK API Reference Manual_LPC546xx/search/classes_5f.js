var searchData=
[
  ['_5fdmic_5fdma_5fhandle',['_dmic_dma_handle',['../group__dmic__dma__driver.html#struct__dmic__dma__handle',1,'']]],
  ['_5fenet_5fhandle',['_enet_handle',['../group__lpc__enet.html#struct__enet__handle',1,'']]],
  ['_5fi2c_5fmaster_5fdma_5fhandle',['_i2c_master_dma_handle',['../group__i2c__dma__driver.html#struct__i2c__master__dma__handle',1,'']]],
  ['_5fi2c_5fmaster_5fhandle',['_i2c_master_handle',['../group__i2c__master__driver.html#struct__i2c__master__handle',1,'']]],
  ['_5fi2c_5fmaster_5ftransfer',['_i2c_master_transfer',['../group__i2c__master__driver.html#struct__i2c__master__transfer',1,'']]],
  ['_5fi2c_5fslave_5fhandle',['_i2c_slave_handle',['../group__i2c__slave__driver.html#struct__i2c__slave__handle',1,'']]],
  ['_5fi2s_5fdma_5fhandle',['_i2s_dma_handle',['../group__i2s__dma__driver.html#struct__i2s__dma__handle',1,'']]],
  ['_5fi2s_5fhandle',['_i2s_handle',['../group__i2s__driver.html#struct__i2s__handle',1,'']]],
  ['_5fmcan_5fhandle',['_mcan_handle',['../group__mcan.html#struct__mcan__handle',1,'']]],
  ['_5fspi_5fdma_5fhandle',['_spi_dma_handle',['../group__spi__dma__driver.html#struct__spi__dma__handle',1,'']]],
  ['_5fspi_5fmaster_5fhandle',['_spi_master_handle',['../group__spi__driver.html#struct__spi__master__handle',1,'']]],
  ['_5fspifi_5fdma_5fhandle',['_spifi_dma_handle',['../group__spifi.html#struct__spifi__dma__handle',1,'']]],
  ['_5fusart_5fdma_5fhandle',['_usart_dma_handle',['../group__usart__dma__driver.html#struct__usart__dma__handle',1,'']]],
  ['_5fusart_5fhandle',['_usart_handle',['../group__usart__driver.html#struct__usart__handle',1,'']]]
];
