var searchData=
[
  ['dma_5fchannel_5fconfig_5ft',['dma_channel_config_t',['../group__dma.html#structdma__channel__config__t',1,'']]],
  ['dma_5fchannel_5ftrigger_5ft',['dma_channel_trigger_t',['../group__dma.html#structdma__channel__trigger__t',1,'']]],
  ['dma_5fdescriptor_5ft',['dma_descriptor_t',['../group__dma.html#structdma__descriptor__t',1,'']]],
  ['dma_5fhandle_5ft',['dma_handle_t',['../group__dma.html#structdma__handle__t',1,'']]],
  ['dma_5ftransfer_5fconfig_5ft',['dma_transfer_config_t',['../group__dma.html#structdma__transfer__config__t',1,'']]],
  ['dma_5fxfercfg_5ft',['dma_xfercfg_t',['../group__dma.html#structdma__xfercfg__t',1,'']]],
  ['dmic_5fchannel_5fconfig_5ft',['dmic_channel_config_t',['../group__dmic__driver.html#structdmic__channel__config__t',1,'']]],
  ['dmic_5ftransfer_5ft',['dmic_transfer_t',['../group__dmic__dma__driver.html#structdmic__transfer__t',1,'']]]
];
