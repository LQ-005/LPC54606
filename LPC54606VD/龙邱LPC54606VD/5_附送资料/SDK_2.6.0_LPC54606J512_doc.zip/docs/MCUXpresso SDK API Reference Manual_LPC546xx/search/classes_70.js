var searchData=
[
  ['panic_5fdata_5ft',['panic_data_t',['../group__Panic.html#structpanic__data__t',1,'']]]
];
