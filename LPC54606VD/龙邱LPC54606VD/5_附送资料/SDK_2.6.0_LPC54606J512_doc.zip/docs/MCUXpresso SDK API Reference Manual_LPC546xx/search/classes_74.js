var searchData=
[
  ['task_5fcontrol_5fblock_5ft',['task_control_block_t',['../group__os__abstraction__bm.html#structtask__control__block__t',1,'']]],
  ['timer_5fconfig_5ft',['timer_config_t',['../group__Timer.html#structtimer__config__t',1,'']]]
];
