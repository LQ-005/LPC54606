var searchData=
[
  ['operation_5fmode_5ft',['operation_mode_t',['../group__dmic__driver.html#ga4dd0057f3dd624cfa8556f28956901b8',1,'fsl_dmic.h']]],
  ['osa_5fstatus_5ft',['osa_status_t',['../group__osa__adapter.html#gac620802974e82799bde8d7eeadecaea2',1,'fsl_os_abstraction.h']]],
  ['osa_5ftimer_5ft',['osa_timer_t',['../group__osa__adapter.html#ga10ef81cbc15f0e714de6812c57b53821',1,'fsl_os_abstraction.h']]],
  ['otp_5fbank_5ft',['otp_bank_t',['../group__otp.html#ga2f7ff30457e4b62ecbf532934c9b5dd7',1,'fsl_otp.h']]],
  ['otp_5flock_5ft',['otp_lock_t',['../group__otp.html#gaff0a672e23beecf3017e9313ffbcc857',1,'fsl_otp.h']]],
  ['otp_5fword_5ft',['otp_word_t',['../group__otp.html#ga5ee856431f8f83aff4e05325a0afe5e9',1,'fsl_otp.h']]]
];
