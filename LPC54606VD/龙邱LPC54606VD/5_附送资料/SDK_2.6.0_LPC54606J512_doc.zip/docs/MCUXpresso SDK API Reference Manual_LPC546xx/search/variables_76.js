var searchData=
[
  ['valid',['valid',['../group__dma.html#a4a97a76d0d7266ee9cc8de82d19e5d81',1,'dma_xfercfg_t']]],
  ['vbp',['vbp',['../group__lpc__lcdc.html#gac027e5cb2b4b60046dd714196d592040',1,'lcdc_config_t']]],
  ['vfp',['vfp',['../group__lpc__lcdc.html#gaf6ed7447e288a9195368de898347528e',1,'lcdc_config_t']]],
  ['vsw',['vsw',['../group__lpc__lcdc.html#ga510c51151d0e6b1de531888b7205f695',1,'lcdc_config_t']]]
];
