var searchData=
[
  ['g_5fserialhandle',['g_serialHandle',['../group__debugconsole.html#gaad3c4240a1364156a239471ccdb9aa0b',1,'fsl_debug_console.h']]],
  ['gainshft',['gainshft',['../group__dmic__driver.html#a450421370b638b59ffa272bae6071c2c',1,'dmic_channel_config_t']]],
  ['green',['green',['../group__lpc__lcdc.html#ga9015580a02a801fc1f2d977533e42fc0',1,'lcdc_cursor_palette_t']]],
  ['greenpin',['greenPin',['../group__LED.html#a835152efe09363fdb1c7c1a4c8a525a4',1,'led_rgb_config_t']]]
];
