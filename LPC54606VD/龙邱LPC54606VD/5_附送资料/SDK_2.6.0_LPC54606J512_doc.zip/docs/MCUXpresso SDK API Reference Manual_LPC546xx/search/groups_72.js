var searchData=
[
  ['rit_3a_20repetitive_20interrupt_20timer',['RIT: Repetitive Interrupt Timer',['../group__rit.html',1,'']]],
  ['rng_3a_20random_20number_20generator',['RNG: Random Number Generator',['../group__rng.html',1,'']]],
  ['rtc_3a_20real_20time_20clock',['RTC: Real Time Clock',['../group__rtc.html',1,'']]]
];
