var searchData=
[
  ['osa_5fevent_5fflags_5ft',['osa_event_flags_t',['../group__osa__adapter.html#ga282940489533ac4bf9b98bb7bc3dadd1',1,'fsl_os_abstraction.h']]],
  ['osa_5fevent_5fhandle_5ft',['osa_event_handle_t',['../group__osa__adapter.html#ga800f6346ade64a29d6b9a8dcec87fa70',1,'fsl_os_abstraction.h']]],
  ['osa_5fmsg_5fhandle_5ft',['osa_msg_handle_t',['../group__osa__adapter.html#ga4476723e61d25fbdc15580e7550a7d7e',1,'fsl_os_abstraction.h']]],
  ['osa_5fmsgq_5fhandle_5ft',['osa_msgq_handle_t',['../group__osa__adapter.html#ga85cf3c01d07c577a5f3e23e0a40a2b64',1,'fsl_os_abstraction.h']]],
  ['osa_5fmutex_5fhandle_5ft',['osa_mutex_handle_t',['../group__osa__adapter.html#ga2f32f00a98f059a0de5dce110c4c55a6',1,'fsl_os_abstraction.h']]],
  ['osa_5fsemaphore_5fhandle_5ft',['osa_semaphore_handle_t',['../group__osa__adapter.html#ga3f5010db706a11ffd2b2c1701f7c2c0e',1,'fsl_os_abstraction.h']]],
  ['osa_5ftask_5fhandle_5ft',['osa_task_handle_t',['../group__osa__adapter.html#gaff220797f9205a2563e90247af14b5d0',1,'fsl_os_abstraction.h']]],
  ['osa_5ftask_5fparam_5ft',['osa_task_param_t',['../group__osa__adapter.html#gacf27b88806f35c8682851354a9360310',1,'fsl_os_abstraction.h']]],
  ['osa_5ftask_5fpriority_5ft',['osa_task_priority_t',['../group__osa__adapter.html#ga9073847cf3f5fa77633bad8284a6255c',1,'fsl_os_abstraction.h']]],
  ['osa_5ftask_5fptr_5ft',['osa_task_ptr_t',['../group__osa__adapter.html#ga5dc7b5e6c130c18b4b7d0f3e4edab7ab',1,'fsl_os_abstraction.h']]],
  ['osa_5ftimer_5ffct_5fptr_5ft',['osa_timer_fct_ptr_t',['../group__osa__adapter.html#ga9931a8d0f995122c66bd5ed226617231',1,'fsl_os_abstraction.h']]],
  ['osa_5ftimer_5fhandle_5ft',['osa_timer_handle_t',['../group__osa__adapter.html#gaed2e72cb6b91506095526418b36c8dbe',1,'fsl_os_abstraction.h']]]
];
