var searchData=
[
  ['sctimer_5fevent_5fcallback_5ft',['sctimer_event_callback_t',['../group__sctimer.html#ga9522e37a144ad51ffb1f5d035f1b4489',1,'fsl_sctimer.h']]],
  ['sdif_5ftransfer_5ffunction_5ft',['sdif_transfer_function_t',['../group__sdif.html#ga24f457e1fc3ee1d874b8174efd5d554b',1,'fsl_sdif.h']]],
  ['serial_5fmanager_5fcallback_5ft',['serial_manager_callback_t',['../group__serialmanager.html#gabe6a6263bb1570ea715938b2420af773',1,'serial_manager.h']]],
  ['spi_5fdma_5fcallback_5ft',['spi_dma_callback_t',['../group__spi__dma__driver.html#ga72ce9db8c2a57d66c7b508ca7891f4b3',1,'fsl_spi_dma.h']]],
  ['spi_5fmaster_5fcallback_5ft',['spi_master_callback_t',['../group__spi__driver.html#gae9bd140aeb645efab6c7552b3994e01a',1,'fsl_spi.h']]],
  ['spi_5fslave_5fcallback_5ft',['spi_slave_callback_t',['../group__spi__driver.html#ga86b45b85e036adc762eed5bcd2a0491d',1,'fsl_spi.h']]],
  ['spi_5fslave_5fhandle_5ft',['spi_slave_handle_t',['../group__spi__driver.html#gad267cfee3a876b2860217ff94f03f574',1,'fsl_spi.h']]],
  ['spifi_5fdma_5fcallback_5ft',['spifi_dma_callback_t',['../group__spifi.html#ga1653912b903b8e56fd3a59b8aeff56e2',1,'fsl_spifi_dma.h']]],
  ['status_5ft',['status_t',['../group__ksdk__common.html#gaaabdaf7ee58ca7269bd4bf24efcde092',1,'fsl_common.h']]]
];
