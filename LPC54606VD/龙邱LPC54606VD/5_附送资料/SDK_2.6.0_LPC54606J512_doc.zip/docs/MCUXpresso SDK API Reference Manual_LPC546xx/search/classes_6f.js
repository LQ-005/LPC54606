var searchData=
[
  ['osa_5ftask_5fdef_5ft',['osa_task_def_t',['../group__osa__adapter.html#structosa__task__def__t',1,'']]],
  ['osa_5fthread_5flink_5ft',['osa_thread_link_t',['../group__osa__adapter.html#structosa__thread__link__t',1,'']]],
  ['osa_5ftime_5fdef_5ft',['osa_time_def_t',['../group__osa__adapter.html#structosa__time__def__t',1,'']]]
];
