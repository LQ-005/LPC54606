var searchData=
[
  ['xfercfg',['xferCfg',['../group__dma.html#a93ad6347b6c5e7c72320be81a67f6baf',1,'dma_channel_config_t::xferCfg()'],['../group__dma.html#ad49be57eb231061b32b021a8854fe425',1,'dma_descriptor_t::xfercfg()'],['../group__dma.html#a365dbf9376f6927bc8b6527ce136914c',1,'dma_transfer_config_t::xfercfg()']]],
  ['xtd',['xtd',['../group__mcan.html#a84db8d1814924c698012bec5805e5a83',1,'mcan_tx_buffer_frame_t::xtd()'],['../group__mcan.html#a4353ac88f35debfb0eb1042ef49ab19d',1,'mcan_rx_buffer_frame_t::xtd()']]]
];
