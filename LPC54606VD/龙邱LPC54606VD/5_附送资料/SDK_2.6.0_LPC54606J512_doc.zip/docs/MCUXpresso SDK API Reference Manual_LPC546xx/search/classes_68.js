var searchData=
[
  ['hal_5fgpio_5fpin_5fconfig_5ft',['hal_gpio_pin_config_t',['../group__GPIO__Adapter.html#structhal__gpio__pin__config__t',1,'']]],
  ['hal_5ftimer_5fconfig_5ft',['hal_timer_config_t',['../group__Timer__Adapter.html#structhal__timer__config__t',1,'']]],
  ['hal_5fuart_5fconfig_5ft',['hal_uart_config_t',['../group__UART__Adapter.html#structhal__uart__config__t',1,'']]],
  ['hal_5fuart_5ftransfer_5ft',['hal_uart_transfer_t',['../group__UART__Adapter.html#structhal__uart__transfer__t',1,'']]]
];
