var searchData=
[
  ['hal_5fgpio_5fcallback_5ft',['hal_gpio_callback_t',['../group__GPIO__Adapter.html#gad4a2e0e1b0d854d5b1b00fe015a3bac4',1,'gpio.h']]],
  ['hal_5fgpio_5fhandle_5ft',['hal_gpio_handle_t',['../group__GPIO__Adapter.html#ga65ce2559011621a603cdb375b1a2bc10',1,'gpio.h']]],
  ['hal_5ftimer_5fcallback_5ft',['hal_timer_callback_t',['../group__Timer__Adapter.html#ga3a11455ac6393e9d8ea9ed654dd0756b',1,'timer.h']]],
  ['hal_5ftimer_5fhandle_5ft',['hal_timer_handle_t',['../group__Timer__Adapter.html#ga35758cf1fce36cd940d538daf3165399',1,'timer.h']]],
  ['hal_5fuart_5ftransfer_5fcallback_5ft',['hal_uart_transfer_callback_t',['../group__UART__Adapter.html#ga465cf4da9359face10f612a6efa72ff0',1,'uart.h']]]
];
