var searchData=
[
  ['debug_20console',['Debug Console',['../group__debugconsole.html',1,'']]],
  ['dma_3a_20direct_20memory_20access_20controller_20driver',['DMA: Direct Memory Access Controller Driver',['../group__dma.html',1,'']]],
  ['dmic_3a_20digital_20microphone',['DMIC: Digital Microphone',['../group__dmic.html',1,'']]],
  ['dmic_20dma_20driver',['DMIC DMA Driver',['../group__dmic__dma__driver.html',1,'']]],
  ['dmic_20driver',['DMIC Driver',['../group__dmic__driver.html',1,'']]]
];
